package com.example.gestionproyectos.service;

import com.example.gestionproyectos.model.Tarea;
import com.example.gestionproyectos.repository.TareaRepository;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class TareaService {

    private final TareaRepository tareaRepository;

    public TareaService(TareaRepository tareaRepository) {
        this.tareaRepository = tareaRepository;
    }

    // Listar todas las tareas
    public List<Tarea> listarTareas() {
        return tareaRepository.findAll();
    }

    // Obtener una tarea por ID
    public Optional<Tarea> obtenerTareaPorId(Long id) {
        return tareaRepository.findById(id);
    }

    // Guardar una nueva tarea
    public Tarea guardarTarea(Tarea tarea) {
        return tareaRepository.save(tarea);
    }

    // Eliminar una tarea por ID
    public void eliminarTarea(Long id) {
        tareaRepository.deleteById(id);
    }
}
