package com.example.gestionproyectos.controller;

import com.example.gestionproyectos.model.Usuario;
import com.example.gestionproyectos.repository.UsuarioRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/")
public class AuthController {

    private final UsuarioRepository usuarioRepository;
    private final PasswordEncoder passwordEncoder;

    public AuthController(UsuarioRepository usuarioRepository, PasswordEncoder passwordEncoder) {
        this.usuarioRepository = usuarioRepository;
        this.passwordEncoder = passwordEncoder;
    }

    // ✅ Redirigir la raíz "/" al login
    @GetMapping("/")
    public String redirigirAlLogin() {
        return "redirect:/login";  // 🔹 Asegura que la aplicación inicie en login
    }

    // ✅ Mostrar formulario de login
    @GetMapping("/login")
    public String mostrarFormularioLogin(@RequestParam(value = "error", required = false) String error,
                                         @RequestParam(value = "logout", required = false) String logout,
                                         Model model) {
        if (error != null) {
            model.addAttribute("error", "Usuario o contraseña incorrectos.");
        }
        if (logout != null) {
            model.addAttribute("logout", "Has cerrado sesión correctamente.");
        }
        return "autenticacion/login";
    }

    // ✅ Mostrar formulario de registro
    @GetMapping("/registro")
    public String mostrarFormularioRegistro(Model model) {
        model.addAttribute("usuario", new Usuario());
        return "autenticacion/registro";
    }

    // ✅ Procesar el registro
    @PostMapping("/registro")
    public String registrarUsuario(@ModelAttribute Usuario usuario) {
        if (usuarioRepository.findByUsername(usuario.getUsername()).isPresent()) {
            return "redirect:/registro?error=usuario_ya_existe";
        }
        usuario.setPassword(passwordEncoder.encode(usuario.getPassword())); // 🔐 Encriptar
        usuario.setRole("USER");
        usuarioRepository.save(usuario);
        return "redirect:/login?success";
    }
}
