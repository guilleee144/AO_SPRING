package com.example.gestionproyectos.model;

import jakarta.persistence.*;
import java.util.List;

@Entity
@Table(name = "proyectos")
public class Proyecto {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 100)
    private String nombre;

    @Column(columnDefinition = "TEXT")
    private String descripcion;

    @Column(name = "fecha_inicio")
    private java.sql.Date fechaInicio;

    @Column(name = "fecha_fin")
    private java.sql.Date fechaFin;

    @ManyToOne
    @JoinColumn(name = "usuario_id", nullable = false)
    private Usuario usuario;

    @OneToMany(mappedBy = "proyecto", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<Tarea> tareas; // 🔹 Agregar relación con `Tarea`

    // 🔽 Getters y Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }

    public java.sql.Date getFechaInicio() { return fechaInicio; }
    public void setFechaInicio(java.sql.Date fechaInicio) { this.fechaInicio = fechaInicio; }

    public java.sql.Date getFechaFin() { return fechaFin; }
    public void setFechaFin(java.sql.Date fechaFin) { this.fechaFin = fechaFin; }

    public Usuario getUsuario() { return usuario; }
    public void setUsuario(Usuario usuario) { this.usuario = usuario; }

    public List<Tarea> getTareas() { return tareas; } // 🔹 Agregar este getter
    public void setTareas(List<Tarea> tareas) { this.tareas = tareas; }
}
