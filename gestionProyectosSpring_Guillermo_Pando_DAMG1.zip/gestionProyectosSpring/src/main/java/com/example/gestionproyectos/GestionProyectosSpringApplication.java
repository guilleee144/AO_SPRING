package com.example.gestionproyectos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestionProyectosSpringApplication {

    public static void main(String[] args) {
        SpringApplication.run(GestionProyectosSpringApplication.class, args);
    }

}
