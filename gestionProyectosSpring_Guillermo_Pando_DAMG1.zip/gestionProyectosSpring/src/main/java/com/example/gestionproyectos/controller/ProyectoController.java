package com.example.gestionproyectos.controller;

import com.example.gestionproyectos.model.Proyecto;
import com.example.gestionproyectos.model.Usuario;
import com.example.gestionproyectos.repository.ProyectoRepository;
import com.example.gestionproyectos.repository.UsuarioRepository;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@Controller
@RequestMapping("/proyectos")
public class ProyectoController {

    private final ProyectoRepository proyectoRepository;
    private final UsuarioRepository usuarioRepository;

    public ProyectoController(ProyectoRepository proyectoRepository, UsuarioRepository usuarioRepository) {
        this.proyectoRepository = proyectoRepository;
        this.usuarioRepository = usuarioRepository;
    }

    // ✅ Mostrar la lista de proyectos
    @GetMapping
    public String listarProyectos(Model model) {
        model.addAttribute("proyectos", proyectoRepository.findAll());
        return "proyectos/index"; // Apunta a `templates/proyectos/index.html`
    }

    // ✅ Mostrar formulario de creación de proyectos
    @GetMapping("/crear")
    public String mostrarFormularioCrear(Model model) {
        model.addAttribute("proyecto", new Proyecto());
        return "proyectos/form"; // Apunta a `templates/proyectos/crear.html`
    }

    // ✅ Guardar proyecto con usuario autenticado
    @PostMapping("/guardar")
    public String guardarProyecto(@ModelAttribute Proyecto proyecto) {
        // 🔹 Obtener usuario autenticado
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();

        // 🔹 Buscar el usuario en la base de datos
        Usuario usuario = usuarioRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado"));

        // 🔹 Asignar usuario autenticado al proyecto
        proyecto.setUsuario(usuario);

        // 🔹 Guardar el proyecto
        proyectoRepository.save(proyecto);
        return "redirect:/proyectos";
    }
    // ✅ Eliminar un proyecto
    @PostMapping("/eliminar/{id}")
    public String eliminarProyecto(@PathVariable Long id) {
        proyectoRepository.deleteById(id);
        return "redirect:/proyectos"; // 🔹 Redirige a la lista de proyectos después de eliminar
    }

    // ✅ Mostrar detalles de un proyecto
    @GetMapping("/{id}")
    public String verDetallesProyecto(@PathVariable Long id, Model model) {
        Optional<Proyecto> proyecto = proyectoRepository.findById(id);
        if (proyecto.isPresent()) {
            model.addAttribute("proyecto", proyecto.get());
            return "proyectos/detalles"; // Apunta a `templates/proyectos/detalles.html`
        }
        return "redirect:/proyectos";
    }
}
