package com.example.gestionproyectos.controller;

import com.example.gestionproyectos.model.Proyecto;
import com.example.gestionproyectos.model.Tarea;
import com.example.gestionproyectos.repository.ProyectoRepository;
import com.example.gestionproyectos.repository.TareaRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/tareas")
public class TareaController {

    private final TareaRepository tareaRepository;
    private final ProyectoRepository proyectoRepository;

    public TareaController(TareaRepository tareaRepository, ProyectoRepository proyectoRepository) {
        this.tareaRepository = tareaRepository;
        this.proyectoRepository = proyectoRepository;
    }

    // ✅ Listar todas las tareas sin importar el proyecto
    @GetMapping
    public String listarTodasLasTareas(Model model) {
        List<Tarea> tareas = tareaRepository.findAll();
        model.addAttribute("tareas", tareas);
        return "tareas/index2"; // ✅ Asegúrate de que `index2.html` existe
    }

    // ✅ Mostrar formulario para crear una tarea (seleccionando proyecto)
    @GetMapping("/crear")
    public String mostrarFormularioCrear(Model model) {
        model.addAttribute("tarea", new Tarea());
        model.addAttribute("proyectos", proyectoRepository.findAll()); // Listar proyectos disponibles
        return "tareas/form2";
    }

    // ✅ Guardar tarea asociada a un proyecto
    @PostMapping("/guardar")
    public String guardarTarea(@ModelAttribute Tarea tarea) {
        if (tarea.getProyecto() == null || tarea.getProyecto().getId() == null) {
            return "redirect:/tareas/crear?error=seleccione_proyecto";
        }
        tareaRepository.save(tarea);
        return "redirect:/tareas";
    }
    // ✅ Eliminar una tarea
    @PostMapping("/eliminar/{id}")
    public String eliminarTarea(@PathVariable Long id) {
        tareaRepository.deleteById(id);
        return "redirect:/tareas"; // 🔹 Redirige a la lista de tareas después de eliminar
    }


    // ✅ Mostrar detalles de una tarea, incluyendo su proyecto asignado
    @GetMapping("/{id}")
    public String verDetallesTarea(@PathVariable Long id, Model model) {
        Optional<Tarea> tarea = tareaRepository.findById(id);
        if (tarea.isPresent()) {
            model.addAttribute("tarea", tarea.get());
            return "tareas/detalles2"; // ✅ Asegúrate de que `detalles2.html` existe
        }
        return "redirect:/tareas";
    }
}
