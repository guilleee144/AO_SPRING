package com.example.gestionproyectos.repository;

import com.example.gestionproyectos.model.Tarea;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TareaRepository extends JpaRepository<Tarea, Long> {

    // ✅ Buscar tareas por ID del proyecto
    List<Tarea> findByProyecto_Id(Long proyectoId);
}
