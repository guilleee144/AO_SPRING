package com.example.gestionproyectos.repository;

import com.example.gestionproyectos.model.Usuario; // Importa la entidad Usuario
import org.springframework.data.jpa.repository.JpaRepository; // Importa JpaRepository para acceso a datos
import org.springframework.stereotype.Repository; // Anotación para indicar que esta interfaz es un repositorio

import java.util.Optional; // Importa Optional para manejar valores que pueden estar vacíos

@Repository // Indica que esta interfaz es un componente de repositorio de Spring
public interface UsuarioRepository extends JpaRepository<Usuario, Long> {

    // ✅ Buscar un usuario por su nombre de usuario
    Optional<Usuario> findByUsername(String username);
    // 🔹 Genera automáticamente la consulta SQL equivalente a:
    // SELECT * FROM usuarios WHERE username = ?;
}
