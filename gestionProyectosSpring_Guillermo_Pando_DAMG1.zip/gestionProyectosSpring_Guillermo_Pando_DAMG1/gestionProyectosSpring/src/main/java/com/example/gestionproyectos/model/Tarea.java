package com.example.gestionproyectos.model;

import jakarta.persistence.*; // Importa las anotaciones de JPA para mapear la entidad en la base de datos

@Entity // Indica que esta clase es una entidad JPA, se mapeará a una tabla en la base de datos
public class Tarea {

    @Id // Define el campo `id` como clave primaria
    @GeneratedValue(strategy = GenerationType.IDENTITY) // Genera automáticamente el ID de manera incremental
    private Long id;

    private String descripcion; // Almacena la descripción de la tarea

    // 🔹 Relación con `Proyecto` (Muchas tareas pueden pertenecer a un solo proyecto)
    @ManyToOne // Define una relación muchos-a-uno con la entidad `Proyecto`
    @JoinColumn(name = "proyecto_id", nullable = false) // Especifica la clave foránea en la base de datos (obligatoria)
    private Proyecto proyecto;

    // 🔽 Métodos Getters y Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }

    public Proyecto getProyecto() { return proyecto; }
    public void setProyecto(Proyecto proyecto) { this.proyecto = proyecto; }
}
