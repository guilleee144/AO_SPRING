package com.example.gestionproyectos.repository;

import com.example.gestionproyectos.model.Tarea; // Importa la entidad Tarea
import org.springframework.data.jpa.repository.JpaRepository; // Importa JpaRepository para acceso a datos
import org.springframework.stereotype.Repository; // Anotación para indicar que esta interfaz es un repositorio

import java.util.List; // Importa List para manejar colecciones de tareas

@Repository // Indica que esta interfaz es un componente de repositorio de Spring
public interface TareaRepository extends JpaRepository<Tarea, Long> {

    // ✅ Buscar tareas por ID del proyecto
    List<Tarea> findByProyecto_Id(Long proyectoId);
    // 🔹 Genera automáticamente la consulta SQL equivalente a:
    // SELECT * FROM tareas WHERE proyecto_id = ?;
}
