package com.example.gestionproyectos.controller;

import com.example.gestionproyectos.model.Proyecto;
import com.example.gestionproyectos.model.Tarea;
import com.example.gestionproyectos.repository.ProyectoRepository;
import com.example.gestionproyectos.repository.TareaRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@Controller // Indica que esta clase es un controlador en Spring MVC
@RequestMapping("/tareas") // Define el prefijo de todas las rutas manejadas en este controlador
public class TareaController {

    private final TareaRepository tareaRepository; // Repositorio para manejar tareas en la base de datos
    private final ProyectoRepository proyectoRepository; // Repositorio para manejar proyectos en la base de datos

    // Constructor que inyecta las dependencias del repositorio de tareas y proyectos
    public TareaController(TareaRepository tareaRepository, ProyectoRepository proyectoRepository) {
        this.tareaRepository = tareaRepository;
        this.proyectoRepository = proyectoRepository;
    }

    // ✅ Listar todas las tareas sin importar el proyecto
    @GetMapping // Maneja solicitudes GET en "/tareas"
    public String listarTodasLasTareas(Model model) {
        List<Tarea> tareas = tareaRepository.findAll(); // Obtiene todas las tareas de la base de datos
        model.addAttribute("tareas", tareas); // Agrega la lista de tareas al modelo para la vista
        return "tareas/index2"; // Retorna la vista `templates/tareas/index2.html`
    }

    // ✅ Mostrar formulario para crear una tarea (seleccionando proyecto)
    @GetMapping("/crear") // Maneja solicitudes GET en "/tareas/crear"
    public String mostrarFormularioCrear(Model model) {
        model.addAttribute("tarea", new Tarea()); // Agrega un objeto vacío de `Tarea` para ser llenado en el formulario
        model.addAttribute("proyectos", proyectoRepository.findAll()); // Obtiene todos los proyectos disponibles
        return "tareas/form2"; // Retorna la vista `templates/tareas/form2.html`
    }

    // ✅ Guardar tarea asociada a un proyecto
    @PostMapping("/guardar") // Maneja solicitudes POST en "/tareas/guardar"
    public String guardarTarea(@ModelAttribute Tarea tarea) {
        // 🔹 Verifica que la tarea tenga un proyecto asignado antes de guardarla
        if (tarea.getProyecto() == null || tarea.getProyecto().getId() == null) {
            return "redirect:/tareas/crear?error=seleccione_proyecto"; // Redirige con un error si no se selecciona un proyecto
        }
        tareaRepository.save(tarea); // Guarda la tarea en la base de datos
        return "redirect:/tareas"; // Redirige a la lista de tareas después de guardar
    }

    // ✅ Eliminar una tarea
    @PostMapping("/eliminar/{id}") // Maneja solicitudes POST en "/tareas/eliminar/{id}"
    public String eliminarTarea(@PathVariable Long id) {
        tareaRepository.deleteById(id); // Elimina la tarea con el ID especificado
        return "redirect:/tareas"; // Redirige a la lista de tareas después de eliminar
    }

    // ✅ Mostrar detalles de una tarea, incluyendo su proyecto asignado
    @GetMapping("/{id}") // Maneja solicitudes GET en "/tareas/{id}"
    public String verDetallesTarea(@PathVariable Long id, Model model) {
        Optional<Tarea> tarea = tareaRepository.findById(id); // Busca la tarea por su ID en la base de datos

        if (tarea.isPresent()) { // Si la tarea existe
            model.addAttribute("tarea", tarea.get()); // Agrega la tarea al modelo
            return "tareas/detalles2"; // Retorna la vista `templates/tareas/detalles2.html`
        }

        return "redirect:/tareas"; // Si la tarea no existe, redirige a la lista de tareas
    }
}
