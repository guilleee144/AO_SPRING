package com.example.gestionproyectos.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration // Indica que esta clase contiene configuraciones para el contexto de Spring
@EnableWebSecurity // Habilita la seguridad en la aplicación con Spring Security
public class SecurityConfig {

    @Bean // Define este método como un bean de Spring para ser utilizado en la configuración
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                .authorizeHttpRequests(auth -> auth
                        .requestMatchers("/login", "/css/**").permitAll() // 🔹 Permite acceso sin autenticación a /login y archivos CSS
                        .requestMatchers("/proyectos/**").authenticated() // 🔹 Requiere autenticación para acceder a "/proyectos/**"
                        .anyRequest().authenticated() // 🔹 Cualquier otra solicitud también necesita autenticación
                )
                .formLogin(login -> login
                        .loginPage("/login") // 🔹 Define la página de inicio de sesión
                        .defaultSuccessUrl("/proyectos", true) // 🔹 Redirige a "/proyectos" tras un login exitoso
                        .permitAll() // 🔹 Permite acceso a todos a la página de login
                )
                .logout(logout -> logout
                        .logoutUrl("/logout") // 🔹 Define la URL para cerrar sesión
                        .logoutSuccessUrl("/login?logout") // 🔹 Redirige a "/login?logout" tras cerrar sesión
                        .permitAll() // 🔹 Permite acceso a todos para cerrar sesión
                );
        return http.build(); // 🔹 Construye y devuelve la configuración de seguridad
    }

    @Bean // Define este método como un bean de Spring para encriptar contraseñas
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder(); // 🔹 Usa BCrypt para encriptar contraseñas antes de guardarlas en la base de datos
    }
}
