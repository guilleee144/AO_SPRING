package com.example.gestionproyectos.controller;

import com.example.gestionproyectos.model.Proyecto;
import com.example.gestionproyectos.model.Usuario;
import com.example.gestionproyectos.repository.ProyectoRepository;
import com.example.gestionproyectos.repository.UsuarioRepository;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@Controller // Indica que esta clase es un controlador en Spring MVC
@RequestMapping("/proyectos") // Define el prefijo de todas las rutas manejadas en este controlador
public class ProyectoController {

    private final ProyectoRepository proyectoRepository; // Repositorio para manejar proyectos en la base de datos
    private final UsuarioRepository usuarioRepository;   // Repositorio para manejar usuarios en la base de datos

    // Constructor que inyecta las dependencias del repositorio de proyectos y usuarios
    public ProyectoController(ProyectoRepository proyectoRepository, UsuarioRepository usuarioRepository) {
        this.proyectoRepository = proyectoRepository;
        this.usuarioRepository = usuarioRepository;
    }

    // ✅ Mostrar la lista de proyectos
    @GetMapping // Maneja solicitudes GET en "/proyectos"
    public String listarProyectos(Model model) {
        model.addAttribute("proyectos", proyectoRepository.findAll()); // Obtiene todos los proyectos y los envía a la vista
        return "proyectos/index"; // Retorna la vista `templates/proyectos/index.html`
    }

    // ✅ Mostrar formulario de creación de proyectos
    @GetMapping("/crear") // Maneja solicitudes GET en "/proyectos/crear"
    public String mostrarFormularioCrear(Model model) {
        model.addAttribute("proyecto", new Proyecto()); // Agrega un nuevo objeto `Proyecto` al modelo para ser llenado en el formulario
        return "proyectos/form"; // Retorna la vista `templates/proyectos/crear.html`
    }

    // ✅ Guardar un proyecto con el usuario autenticado
    @PostMapping("/guardar") // Maneja solicitudes POST en "/proyectos/guardar"
    public String guardarProyecto(@ModelAttribute Proyecto proyecto) {
        // 🔹 Obtener el usuario autenticado
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName(); // Obtiene el nombre de usuario autenticado

        // 🔹 Buscar el usuario en la base de datos
        Usuario usuario = usuarioRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado")); // Si el usuario no existe, lanza una excepción

        // 🔹 Asignar usuario autenticado al proyecto
        proyecto.setUsuario(usuario);

        // 🔹 Guardar el proyecto en la base de datos
        proyectoRepository.save(proyecto);

        return "redirect:/proyectos"; // Redirige a la lista de proyectos después de guardar
    }

    // ✅ Eliminar un proyecto
    @PostMapping("/eliminar/{id}") // Maneja solicitudes POST en "/proyectos/eliminar/{id}"
    public String eliminarProyecto(@PathVariable Long id) {
        proyectoRepository.deleteById(id); // Elimina el proyecto con el ID especificado
        return "redirect:/proyectos"; // Redirige a la lista de proyectos después de eliminar
    }

    // ✅ Mostrar detalles de un proyecto
    @GetMapping("/{id}") // Maneja solicitudes GET en "/proyectos/{id}"
    public String verDetallesProyecto(@PathVariable Long id, Model model) {
        Optional<Proyecto> proyecto = proyectoRepository.findById(id); // Busca el proyecto por su ID en la base de datos

        if (proyecto.isPresent()) { // Si el proyecto existe
            model.addAttribute("proyecto", proyecto.get()); // Agrega el proyecto al modelo
            return "proyectos/detalles"; // Retorna la vista `templates/proyectos/detalles.html`
        }

        return "redirect:/proyectos"; // Si el proyecto no existe, redirige a la lista de proyectos
    }
}
