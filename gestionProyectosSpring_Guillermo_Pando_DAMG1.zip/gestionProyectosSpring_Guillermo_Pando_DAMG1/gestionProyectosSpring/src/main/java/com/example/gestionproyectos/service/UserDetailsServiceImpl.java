package com.example.gestionproyectos.service;

import com.example.gestionproyectos.model.Usuario; // Importa la entidad Usuario
import com.example.gestionproyectos.repository.UsuarioRepository; // Importa el repositorio de Usuario
import org.springframework.security.core.GrantedAuthority; // Representa los permisos del usuario en la seguridad de Spring
import org.springframework.security.core.authority.SimpleGrantedAuthority; // Representa un rol de usuario
import org.springframework.security.core.userdetails.User; // Implementación de UserDetails de Spring Security
import org.springframework.security.core.userdetails.UserDetails; // Interfaz que representa un usuario en Spring Security
import org.springframework.security.core.userdetails.UserDetailsService; // Servicio de Spring Security para manejar autenticación
import org.springframework.security.core.userdetails.UsernameNotFoundException; // Excepción lanzada cuando no se encuentra un usuario
import org.springframework.stereotype.Service; // Marca esta clase como un servicio en Spring

import java.util.Collections; // Importa Collections para manejar listas inmutables
import java.util.List; // Importa List para manejar la colección de roles

@Service // Indica que esta clase es un servicio gestionado por Spring
public class UserDetailsServiceImpl implements UserDetailsService {

    private final UsuarioRepository usuarioRepository; // Repositorio para acceder a la base de datos de usuarios

    // 🔹 Constructor que inyecta el repositorio de usuarios
    public UserDetailsServiceImpl(UsuarioRepository usuarioRepository) {
        this.usuarioRepository = usuarioRepository;
    }

    @Override // Implementación del método de Spring Security para cargar un usuario por su nombre de usuario
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        // 🔹 Busca al usuario en la base de datos por su nombre de usuario
        Usuario usuario = usuarioRepository.findByUsername(username)
                .orElseThrow(() -> new UsernameNotFoundException("Usuario no encontrado"));
        // Si el usuario no existe, lanza una excepción de Spring Security

        // 🔹 Crea una lista con el rol del usuario
        List<GrantedAuthority> authorities = Collections.singletonList(new SimpleGrantedAuthority(usuario.getRole()));
        // `Collections.singletonList(...)` crea una lista inmutable con un solo elemento: el rol del usuario

        // 🔹 Devuelve un objeto `User` de Spring Security con el nombre de usuario, la contraseña y los roles
        return new User(usuario.getUsername(), usuario.getPassword(), authorities);
    }
}
