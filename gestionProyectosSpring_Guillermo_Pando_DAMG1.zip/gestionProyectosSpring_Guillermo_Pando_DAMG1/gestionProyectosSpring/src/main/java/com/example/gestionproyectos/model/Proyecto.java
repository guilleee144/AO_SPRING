package com.example.gestionproyectos.model;

import jakarta.persistence.*; // Importa las anotaciones de JPA necesarias para la persistencia en base de datos
import java.util.List; // Importa la clase List para manejar colecciones de tareas dentro de un proyecto

@Entity // Indica que esta clase es una entidad JPA (se mapeará a una tabla en la base de datos)
@Table(name = "proyectos") // Define el nombre de la tabla en la base de datos
public class Proyecto {

    @Id // Define el campo `id` como clave primaria
    @GeneratedValue(strategy = GenerationType.IDENTITY) // Genera automáticamente el ID de manera incremental
    private Long id;

    @Column(nullable = false, length = 100) // Define que este campo no puede ser nulo y tiene un máximo de 100 caracteres
    private String nombre;

    @Column(columnDefinition = "TEXT") // Define la columna como un campo de texto largo
    private String descripcion;

    @Column(name = "fecha_inicio") // Define el nombre de la columna en la base de datos
    private java.sql.Date fechaInicio; // Almacena la fecha de inicio del proyecto

    @Column(name = "fecha_fin") // Define el nombre de la columna en la base de datos
    private java.sql.Date fechaFin; // Almacena la fecha de finalización del proyecto

    // 🔹 Relación con `Usuario` (Muchos proyectos pueden pertenecer a un solo usuario)
    @ManyToOne // Define una relación muchos-a-uno con la entidad Usuario
    @JoinColumn(name = "usuario_id", nullable = false) // Especifica el nombre de la clave foránea en la base de datos
    private Usuario usuario;

    // 🔹 Relación con `Tarea` (Un proyecto puede tener varias tareas)
    @OneToMany(mappedBy = "proyecto", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    // `mappedBy = "proyecto"`: Indica que la relación está mapeada por el campo `proyecto` en la entidad `Tarea`
    // `cascade = CascadeType.ALL`: Si se elimina un proyecto, se eliminan todas sus tareas asociadas
    // `fetch = FetchType.LAZY`: Carga las tareas solo cuando se accede a ellas, optimizando el rendimiento
    private List<Tarea> tareas;

    // 🔽 Métodos Getters y Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }

    public java.sql.Date getFechaInicio() { return fechaInicio; }
    public void setFechaInicio(java.sql.Date fechaInicio) { this.fechaInicio = fechaInicio; }

    public java.sql.Date getFechaFin() { return fechaFin; }
    public void setFechaFin(java.sql.Date fechaFin) { this.fechaFin = fechaFin; }

    public Usuario getUsuario() { return usuario; }
    public void setUsuario(Usuario usuario) { this.usuario = usuario; }

    public List<Tarea> getTareas() { return tareas; } // 🔹 Devuelve la lista de tareas asociadas al proyecto
    public void setTareas(List<Tarea> tareas) { this.tareas = tareas; } // 🔹 Permite asignar una lista de tareas al proyecto
}
