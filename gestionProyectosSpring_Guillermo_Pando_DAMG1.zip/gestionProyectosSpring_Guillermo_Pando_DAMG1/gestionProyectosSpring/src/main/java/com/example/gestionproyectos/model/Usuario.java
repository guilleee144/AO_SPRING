package com.example.gestionproyectos.model;

import jakarta.persistence.*; // Importa las anotaciones de JPA necesarias para la persistencia en base de datos
import java.util.List; // Importa la clase List para manejar la relación con múltiples proyectos

@Entity // Indica que esta clase es una entidad JPA (se mapeará a una tabla en la base de datos)
@Table(name = "usuarios") // Define el nombre de la tabla en la base de datos
public class Usuario {

    @Id // Define el campo `id` como clave primaria
    @GeneratedValue(strategy = GenerationType.IDENTITY) // Genera automáticamente el ID de manera incremental
    private Long id;

    @Column(unique = true, nullable = false) // Define que este campo debe ser único y no puede ser nulo
    private String username; // Nombre de usuario único para autenticación

    @Column(nullable = false) // Define que este campo no puede ser nulo
    private String password; // Contraseña del usuario (debe almacenarse encriptada)

    @Column(nullable = false) // Define que este campo no puede ser nulo
    private String role; // Rol del usuario (Ej: "USER", "ADMIN")

    // 🔹 Relación con `Proyecto` (Un usuario puede tener varios proyectos)
    @OneToMany(mappedBy = "usuario", cascade = CascadeType.ALL)
    // `mappedBy = "usuario"`: Indica que la relación está mapeada por el campo `usuario` en la entidad `Proyecto`
    // `cascade = CascadeType.ALL`: Si se elimina un usuario, también se eliminan sus proyectos
    private List<Proyecto> proyectos; // Lista de proyectos asociados al usuario

    // 🔽 Métodos Getters y Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

    public String getRole() { return role; } // Devuelve el rol del usuario
    public void setRole(String role) { this.role = role; } // Asigna el rol al usuario

    public List<Proyecto> getProyectos() { return proyectos; } // Devuelve la lista de proyectos del usuario
    public void setProyectos(List<Proyecto> proyectos) { this.proyectos = proyectos; } // Asigna proyectos al usuario
}
