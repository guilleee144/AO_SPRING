package com.example.gestionproyectos.repository;

import com.example.gestionproyectos.model.Proyecto; // Importa la entidad Proyecto
import org.springframework.data.jpa.repository.JpaRepository; // Importa JpaRepository para acceso a datos
import java.util.List; // Importa List para manejar colecciones de proyectos

// 🔹 Interfaz del repositorio para la entidad `Proyecto`
// 🔹 JpaRepository<Proyecto, Long> proporciona métodos CRUD (Create, Read, Update, Delete)
public interface ProyectoRepository extends JpaRepository<Proyecto, Long> {

    // 🔹 Método personalizado para obtener los proyectos de un usuario específico
    List<Proyecto> findByUsuarioId(Long usuarioId);
    // Genera automáticamente la consulta SQL equivalente a:
    // SELECT * FROM proyectos WHERE usuario_id = ?;
}
