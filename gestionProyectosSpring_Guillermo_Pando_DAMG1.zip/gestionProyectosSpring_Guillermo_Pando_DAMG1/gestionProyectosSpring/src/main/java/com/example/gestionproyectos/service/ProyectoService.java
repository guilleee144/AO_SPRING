package com.example.gestionproyectos.service;

import com.example.gestionproyectos.model.Proyecto; // Importa la entidad Proyecto
import com.example.gestionproyectos.repository.ProyectoRepository; // Importa el repositorio de Proyecto
import org.springframework.stereotype.Service; // Indica que esta clase es un servicio en Spring
import java.util.List; // Importa List para manejar colecciones de proyectos
import java.util.Optional; // Importa Optional para manejar valores que pueden estar vacíos

@Service // Marca esta clase como un servicio, lo que permite que Spring la gestione como un componente
public class ProyectoService {

    private final ProyectoRepository proyectoRepository; // Repositorio para manejar operaciones en la base de datos

    // 🔹 Constructor que inyecta el repositorio de proyectos
    public ProyectoService(ProyectoRepository proyectoRepository) {
        this.proyectoRepository = proyectoRepository;
    }

    // ✅ Método para obtener la lista de todos los proyectos
    public List<Proyecto> listarProyectos() {
        return proyectoRepository.findAll(); // Recupera todos los proyectos de la base de datos
    }

    // ✅ Método para obtener un proyecto por su ID
    public Optional<Proyecto> obtenerProyecto(Long id) {
        return proyectoRepository.findById(id); // Busca el proyecto en la base de datos y lo devuelve como Optional
    }

    // ✅ Método para guardar un proyecto en la base de datos
    public void guardarProyecto(Proyecto proyecto) {
        proyectoRepository.save(proyecto); // Guarda el proyecto en la base de datos
    }

    // ✅ Método para eliminar un proyecto por su ID
    public void eliminarProyecto(Long id) {
        proyectoRepository.deleteById(id); // Elimina el proyecto de la base de datos por su ID
    }
}
