package com.example.gestionproyectos.controller;

import com.example.gestionproyectos.model.Usuario;
import com.example.gestionproyectos.repository.UsuarioRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller // Indica que esta clase es un controlador de Spring MVC
@RequestMapping("/") // Define que todas las rutas de este controlador comienzan desde "/"
public class AuthController {

    private final UsuarioRepository usuarioRepository; // Repositorio para manejar los usuarios en la base de datos
    private final PasswordEncoder passwordEncoder; // Codificador de contraseñas para encriptarlas antes de guardarlas

    // Constructor que inyecta el repositorio de usuarios y el encriptador de contraseñas
    public AuthController(UsuarioRepository usuarioRepository, PasswordEncoder passwordEncoder) {
        this.usuarioRepository = usuarioRepository;
        this.passwordEncoder = passwordEncoder;
    }

    // ✅ Redirigir la raíz "/" al login
    @GetMapping("/") // Maneja solicitudes GET en "/"
    public String redirigirAlLogin() {
        return "redirect:/login";  // 🔹 Redirige a la página de login al acceder a la raíz "/"
    }

    // ✅ Mostrar formulario de login
    @GetMapping("/login") // Maneja solicitudes GET en "/login"
    public String mostrarFormularioLogin(@RequestParam(value = "error", required = false) String error,
                                         @RequestParam(value = "logout", required = false) String logout,
                                         Model model) {
        if (error != null) {
            model.addAttribute("error", "Usuario o contraseña incorrectos."); // 🔹 Agrega un mensaje de error si hay un fallo en la autenticación
        }
        if (logout != null) {
            model.addAttribute("logout", "Has cerrado sesión correctamente."); // 🔹 Agrega un mensaje de cierre de sesión exitoso
        }
        return "autenticacion/login"; // 🔹 Retorna la vista `templates/autenticacion/login.html`
    }

    // ✅ Mostrar formulario de registro
    @GetMapping("/registro") // Maneja solicitudes GET en "/registro"
    public String mostrarFormularioRegistro(Model model) {
        model.addAttribute("usuario", new Usuario()); // 🔹 Agrega un objeto vacío de `Usuario` para ser llenado en el formulario
        return "autenticacion/registro"; // 🔹 Retorna la vista `templates/autenticacion/registro.html`
    }

    // ✅ Procesar el registro de un usuario
    @PostMapping("/registro") // Maneja solicitudes POST en "/registro"
    public String registrarUsuario(@ModelAttribute Usuario usuario) {
        // 🔹 Verifica si el nombre de usuario ya está registrado
        if (usuarioRepository.findByUsername(usuario.getUsername()).isPresent()) {
            return "redirect:/registro?error=usuario_ya_existe"; // 🔹 Redirige al registro con un mensaje de error si el usuario ya existe
        }

        // 🔹 Encripta la contraseña antes de guardarla en la base de datos
        usuario.setPassword(passwordEncoder.encode(usuario.getPassword()));

        // 🔹 Asigna el rol "USER" por defecto al usuario registrado
        usuario.setRole("USER");

        // 🔹 Guarda el usuario en la base de datos
        usuarioRepository.save(usuario);

        return "redirect:/login?success"; // 🔹 Redirige a la página de login con un mensaje de éxito
    }
}
