package com.example.gestionproyectos.service;

import com.example.gestionproyectos.model.Tarea; // Importa la entidad Tarea
import com.example.gestionproyectos.repository.TareaRepository; // Importa el repositorio de Tarea
import org.springframework.stereotype.Service; // Indica que esta clase es un servicio en Spring
import java.util.List; // Importa List para manejar colecciones de tareas
import java.util.Optional; // Importa Optional para manejar valores que pueden estar vacíos

@Service // Marca esta clase como un servicio, lo que permite que Spring la gestione como un componente
public class TareaService {

    private final TareaRepository tareaRepository; // Repositorio para manejar operaciones en la base de datos

    // 🔹 Constructor que inyecta el repositorio de tareas
    public TareaService(TareaRepository tareaRepository) {
        this.tareaRepository = tareaRepository;
    }

    // ✅ Método para obtener la lista de todas las tareas
    public List<Tarea> listarTareas() {
        return tareaRepository.findAll(); // Recupera todas las tareas de la base de datos
    }

    // ✅ Método para obtener una tarea por su ID
    public Optional<Tarea> obtenerTareaPorId(Long id) {
        return tareaRepository.findById(id); // Busca la tarea en la base de datos y la devuelve como Optional
    }

    // ✅ Método para guardar una nueva tarea o actualizar una existente
    public Tarea guardarTarea(Tarea tarea) {
        return tareaRepository.save(tarea); // Guarda la tarea en la base de datos
    }

    // ✅ Método para eliminar una tarea por su ID
    public void eliminarTarea(Long id) {
        tareaRepository.deleteById(id); // Elimina la tarea de la base de datos por su ID
    }
}
