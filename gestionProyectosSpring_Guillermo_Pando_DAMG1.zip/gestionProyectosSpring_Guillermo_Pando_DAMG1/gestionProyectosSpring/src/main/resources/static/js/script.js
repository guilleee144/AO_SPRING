document.addEventListener("DOMContentLoaded", function() {
    console.log("✅ Script cargado correctamente");

    // Manejo de mensajes de error y éxito
    let urlParams = new URLSearchParams(window.location.search);
    if (urlParams.has("error")) {
        alert("⚠️ Error: Usuario o contraseña incorrectos.");
    }
    if (urlParams.has("success")) {
        alert("✅ Registro exitoso. Ahora puedes iniciar sesión.");
    }

    // Validación de contraseñas en el formulario de registro
    let registerForm = document.querySelector("form[action='/registro']");
    if (registerForm) {
        registerForm.addEventListener("submit", function(event) {
            let password = document.getElementById("password").value;
            let confirmPassword = document.getElementById("confirmPassword").value;
            if (password !== confirmPassword) {
                event.preventDefault();
                alert("⚠️ Las contraseñas no coinciden.");
            }
        });
    }

    // Mostrar y ocultar elementos dinámicamente
    let loginForm = document.querySelector("form[action='/login']");
    if (loginForm) {
        console.log("📌 Formulario de inicio de sesión detectado");
    }

    let registerLink = document.querySelector("a[href='/registro']");
    if (registerLink) {
        registerLink.addEventListener("click", function(event) {
            event.preventDefault();
            window.location.href = "/registro";
        });
    }

    let logoutButton = document.getElementById("logoutButton");
    if (logoutButton) {
        logoutButton.addEventListener("click", function() {
            window.location.href = "/logout";
        });
    }
});
